-- ============================================================
-- Lokolo Platform - Additional Constraints & Indexes
-- Version: 1.0
-- Description: Final constraints, composite indexes, and optimizations
-- ============================================================

-- ============================================================
-- COMPOSITE INDEXES for common query patterns
-- ============================================================

-- Business search: active businesses by location and status
DROP INDEX IF EXISTS idx_businesses_active_search;
CREATE INDEX idx_businesses_active_search 
ON businesses(status, verification_status, city) 
WHERE status = 'active';

-- User's businesses lookup
DROP INDEX IF EXISTS idx_businesses_owner_status;
CREATE INDEX idx_businesses_owner_status 
ON businesses(owner_id, status);

-- Unread messages per thread
DROP INDEX IF EXISTS idx_messages_unread;
CREATE INDEX idx_messages_unread 
ON messages(thread_id, is_read, created_at) 
WHERE is_read = FALSE;

-- Consumer's active threads
DROP INDEX IF EXISTS idx_threads_consumer_active;
CREATE INDEX idx_threads_consumer_active 
ON threads(consumer_id, last_message_at) 
WHERE is_archived_by_consumer = FALSE;

-- Supplier's active threads
DROP INDEX IF EXISTS idx_threads_supplier_active;
CREATE INDEX idx_threads_supplier_active 
ON threads(supplier_id, last_message_at) 
WHERE is_archived_by_supplier = FALSE;

-- Pending verification requests
DROP INDEX IF EXISTS idx_verification_pending;
CREATE INDEX idx_verification_pending 
ON verification_requests(status, created_at) 
WHERE status = 'pending';

-- ============================================================
-- ADDITIONAL CONSTRAINTS
-- ============================================================

-- Ensure supplier role for business owners
ALTER TABLE businesses DROP CONSTRAINT IF EXISTS businesses_owner_role_check;
ALTER TABLE businesses ADD CONSTRAINT businesses_owner_role_check 
CHECK (
    owner_id IN (
        SELECT id FROM users WHERE role IN ('supplier', 'admin')
    )
);

-- Ensure consumer role for favorites
ALTER TABLE favorites DROP CONSTRAINT IF EXISTS favorites_consumer_role_check;
ALTER TABLE favorites ADD CONSTRAINT favorites_consumer_role_check 
CHECK (
    user_id IN (
        SELECT id FROM users WHERE role = 'consumer'
    )
);

-- Ensure thread participants have correct roles
ALTER TABLE threads DROP CONSTRAINT IF EXISTS threads_consumer_role_check;
ALTER TABLE threads ADD CONSTRAINT threads_consumer_role_check 
CHECK (
    consumer_id IN (
        SELECT id FROM users WHERE role = 'consumer'
    )
);

ALTER TABLE threads DROP CONSTRAINT IF EXISTS threads_supplier_role_check;
ALTER TABLE threads ADD CONSTRAINT threads_supplier_role_check 
CHECK (
    supplier_id IN (
        SELECT id FROM users WHERE role IN ('supplier', 'admin')
    )
);

-- ============================================================
-- PERFORMANCE: Analyze tables for query planner
-- ============================================================

ANALYZE users;
ANALYZE businesses;
ANALYZE business_media;
ANALYZE business_hours;
ANALYZE business_categories;
ANALYZE favorites;
ANALYZE threads;
ANALYZE messages;
ANALYZE verification_requests;
ANALYZE verification_documents;

-- Update schema version
INSERT INTO schema_version (version, description) 
VALUES ('1.11', 'Added composite indexes and role-based constraints')
ON CONFLICT (version) DO NOTHING;
