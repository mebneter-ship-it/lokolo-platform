-- ============================================================
-- Lokolo Platform - Favorites Table
-- Version: 1.0
-- Description: Consumer favorites (bookmarks) for businesses
-- ============================================================

DROP TABLE IF EXISTS favorites CASCADE;

CREATE TABLE favorites (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Constraints: One favorite per user per business
    CONSTRAINT favorites_unique UNIQUE(user_id, business_id)
);

-- Indexes for performance
CREATE INDEX idx_favorites_user_id ON favorites(user_id);
CREATE INDEX idx_favorites_business_id ON favorites(business_id);
CREATE INDEX idx_favorites_created_at ON favorites(created_at);

-- Update schema version
INSERT INTO schema_version (version, description) 
VALUES ('1.6', 'Added favorites table for consumer bookmarks')
ON CONFLICT (version) DO NOTHING;
