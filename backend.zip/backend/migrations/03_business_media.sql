-- ============================================================
-- Lokolo Platform - Business Media Table
-- Version: 1.0
-- Description: Photos and logos for businesses (max 1 logo, max 3 photos)
-- ============================================================

CREATE TABLE IF NOT EXISTS business_media (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    
    -- Media Details
    media_type media_type NOT NULL,
    storage_path TEXT NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_size_bytes INTEGER,
    mime_type VARCHAR(100),
    
    -- Display
    display_order INTEGER DEFAULT 0,
    alt_text VARCHAR(255),
    
    -- Timestamps
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Metadata
    metadata JSONB DEFAULT '{}'::jsonb
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_business_media_business_id ON business_media(business_id);
CREATE INDEX IF NOT EXISTS idx_business_media_type ON business_media(media_type);
CREATE INDEX IF NOT EXISTS idx_business_media_display_order ON business_media(business_id, display_order);

-- CONSTRAINT: Only 1 logo per business
CREATE UNIQUE INDEX IF NOT EXISTS idx_business_media_unique_logo 
ON business_media(business_id) 
WHERE media_type = 'logo';

-- TRIGGER: Prevent more than 3 photos per business
CREATE OR REPLACE FUNCTION check_max_photos()
RETURNS TRIGGER AS $$
DECLARE
    photo_count INTEGER;
BEGIN
    IF NEW.media_type = 'photo' THEN
        SELECT COUNT(*) INTO photo_count
        FROM business_media
        WHERE business_id = NEW.business_id 
        AND media_type = 'photo';
        
        IF photo_count >= 3 THEN
            RAISE EXCEPTION 'Cannot add more than 3 photos per business';
        END IF;
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER business_media_max_photos
    BEFORE INSERT ON business_media
    FOR EACH ROW
    EXECUTE FUNCTION check_max_photos();

-- Update schema version
INSERT INTO schema_version (version, description) 
VALUES ('1.3', 'Added business_media table with logo/photo constraints')
ON CONFLICT (version) DO NOTHING;
