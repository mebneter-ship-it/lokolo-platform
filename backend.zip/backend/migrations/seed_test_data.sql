-- ============================================================================
-- LOKOLO PLATFORM - TEST DATA SEED SCRIPT
-- Version: 1.0
-- Date: November 14, 2025
-- ============================================================================
-- 
-- This script populates the database with realistic test data covering:
-- - 3 Consumer users
-- - 5 Supplier users  
-- - 1 Admin user
-- - 10 Businesses (various statuses)
-- - Business media, hours, categories
-- - 15 Favorites
-- - 8 Message threads with messages
-- - 3 Verification requests
--
-- CAUTION: This script includes TRUNCATE statements that will delete existing
-- test data. Only run in development environment!
-- ============================================================================

-- Clean existing test data (CAUTION: Only run in development!)
-- Uncomment the lines below if you want to start fresh
-- TRUNCATE TABLE verification_documents CASCADE;
-- TRUNCATE TABLE verification_requests CASCADE;
-- TRUNCATE TABLE messages CASCADE;
-- TRUNCATE TABLE threads CASCADE;
-- TRUNCATE TABLE favorites CASCADE;
-- TRUNCATE TABLE business_categories CASCADE;
-- TRUNCATE TABLE business_hours CASCADE;
-- TRUNCATE TABLE business_media CASCADE;
-- TRUNCATE TABLE businesses CASCADE;
-- TRUNCATE TABLE users CASCADE;

-- ============================================================================
-- USERS
-- ============================================================================

-- Consumer Users (3)
INSERT INTO users (id, firebase_uid, email, phone_number, role, display_name, profile_photo_url, is_active, last_login_at, metadata) VALUES
('550e8400-e29b-41d4-a716-446655440001', 'firebase_consumer_1', 'lindiwe.moyo@example.com', '+27821234567', 'consumer', 'Lindiwe Moyo', NULL, true, NOW(), '{"location": "Johannesburg", "preferences": {"notifications": true}}'),
('550e8400-e29b-41d4-a716-446655440002', 'firebase_consumer_2', 'thabo.dlamini@example.com', '+27829876543', 'consumer', 'Thabo Dlamini', NULL, true, NOW(), '{"location": "Cape Town", "preferences": {"notifications": true}}'),
('550e8400-e29b-41d4-a716-446655440003', 'firebase_consumer_3', 'nomsa.khumalo@example.com', '+27734567890', 'consumer', 'Nomsa Khumalo', NULL, true, NOW(), '{"location": "Durban", "preferences": {"notifications": false}}');

-- Supplier Users (5)
INSERT INTO users (id, firebase_uid, email, phone_number, role, display_name, profile_photo_url, is_active, last_login_at, metadata) VALUES
('550e8400-e29b-41d4-a716-446655440010', 'firebase_supplier_1', 'john.mabaso@example.com', '+27821111111', 'supplier', 'John Mabaso', NULL, true, NOW(), '{"business_owner": true}'),
('550e8400-e29b-41d4-a716-446655440011', 'firebase_supplier_2', 'grace.ndlovu@example.com', '+27822222222', 'supplier', 'Grace Ndlovu', NULL, true, NOW(), '{"business_owner": true}'),
('550e8400-e29b-41d4-a716-446655440012', 'firebase_supplier_3', 'samuel.chauke@example.com', '+27823333333', 'supplier', 'Samuel Chauke', NULL, true, NOW(), '{"business_owner": true}'),
('550e8400-e29b-41d4-a716-446655440013', 'firebase_supplier_4', 'zanele.sibeko@example.com', '+27824444444', 'supplier', 'Zanele Sibeko', NULL, true, NOW(), '{"business_owner": true}'),
('550e8400-e29b-41d4-a716-446655440014', 'firebase_supplier_5', 'tumi.moloi@example.com', '+27825555555', 'supplier', 'Tumi Moloi', NULL, true, NOW(), '{"business_owner": true}');

-- Admin User (1)
INSERT INTO users (id, firebase_uid, email, phone_number, role, display_name, profile_photo_url, is_active, last_login_at, metadata) VALUES
('550e8400-e29b-41d4-a716-446655440100', 'firebase_admin_1', 'admin@lokolo.co.za', '+27820000000', 'admin', 'Lokolo Admin', NULL, true, NOW(), '{"admin_level": "super"}');

-- ============================================================================
-- BUSINESSES
-- ============================================================================

-- Active Verified Businesses (5)
INSERT INTO businesses (id, owner_id, name, tagline, description, email, phone_number, whatsapp_number, website_url, location, address_line1, city, province_state, postal_code, country, year_established, employee_count_range, status, verification_status, verified_at, published_at, metadata) VALUES
('650e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440010', 'Ubuntu Coffee Roasters', 'Artisan coffee from African beans', 'We source premium coffee beans from small African farms and roast them fresh daily. Our café serves specialty coffee drinks and pastries in a warm, community-focused environment.', 'info@ubuntucoffee.co.za', '+27821111111', '+27821111111', 'https://ubuntucoffee.co.za', ST_SetSRID(ST_MakePoint(28.0473, -26.2041), 4326), '123 Rosebank Avenue', 'Johannesburg', 'Gauteng', '2196', 'ZA', 2020, '5-10', 'active', 'approved', NOW() - INTERVAL '30 days', NOW() - INTERVAL '30 days', '{"featured": true, "parking": true}'),

('650e8400-e29b-41d4-a716-446655440002', '550e8400-e29b-41d4-a716-446655440011', 'Amandla Fashion House', 'Contemporary African fashion', 'Designer clothing celebrating African heritage with modern cuts. We create custom pieces and ready-to-wear collections for confident women.', 'hello@amandlafashion.co.za', '+27822222222', '+27822222222', 'https://amandlafashion.co.za', ST_SetSRID(ST_MakePoint(18.4241, -33.9249), 4326), '45 Long Street', 'Cape Town', 'Western Cape', '8001', 'ZA', 2019, '5-10', 'active', 'approved', NOW() - INTERVAL '45 days', NOW() - INTERVAL '45 days', '{"featured": true}'),

('650e8400-e29b-41d4-a716-446655440003', '550e8400-e29b-41d4-a716-446655440012', 'TechHub Innovation Lab', 'Co-working space for African tech startups', 'Modern co-working facility with high-speed internet, meeting rooms, and mentorship programs. We support Black-owned tech startups with resources and community.', 'info@techhubza.co.za', '+27823333333', '+27823333333', 'https://techhubza.co.za', ST_SetSRID(ST_MakePoint(31.0218, -29.8587), 4326), '88 Anton Lembede Street', 'Durban', 'KwaZulu-Natal', '4001', 'ZA', 2021, '10-20', 'active', 'approved', NOW() - INTERVAL '20 days', NOW() - INTERVAL '20 days', '{"wifi": true, "parking": true}'),

('650e8400-e29b-41d4-a716-446655440004', '550e8400-e29b-41d4-a716-446655440013', 'Mama Zanele''s Kitchen', 'Authentic African cuisine', 'Traditional South African dishes prepared with love and fresh ingredients. From bunny chow to pap and chakalaka, we serve the flavors of home.', 'bookings@mamazaneles.co.za', '+27824444444', '+27824444444', NULL, ST_SetSRID(ST_MakePoint(28.0293, -26.2023), 4326), '67 Main Road, Alexandra', 'Johannesburg', 'Gauteng', '2090', 'ZA', 2015, '5-10', 'active', 'approved', NOW() - INTERVAL '60 days', NOW() - INTERVAL '60 days', '{"takeaway": true, "delivery": false}'),

('650e8400-e29b-41d4-a716-446655440005', '550e8400-e29b-41d4-a716-446655440014', 'Tumi''s Natural Hair Studio', 'Expert care for natural African hair', 'Specializing in natural hair care, braiding, locs, and protective styles. Our stylists understand the unique needs of African hair textures.', 'bookings@tumisnaturalhair.co.za', '+27825555555', '+27825555555', 'https://instagram.com/tumisnaturalhair', ST_SetSRID(ST_MakePoint(28.0422, -26.1076), 4326), '234 Rivonia Road, Sandton', 'Johannesburg', 'Gauteng', '2196', 'ZA', 2018, '1-5', 'active', 'approved', NOW() - INTERVAL '40 days', NOW() - INTERVAL '40 days', '{"appointment_only": true}');

-- Pending Verification Businesses (3)
INSERT INTO businesses (id, owner_id, name, tagline, description, email, phone_number, whatsapp_number, website_url, location, address_line1, city, province_state, postal_code, country, year_established, employee_count_range, status, verification_status, published_at, metadata) VALUES
('650e8400-e29b-41d4-a716-446655440006', '550e8400-e29b-41d4-a716-446655440010', 'Ubuntu Bakery', 'Fresh artisan breads daily', 'Sister business to Ubuntu Coffee Roasters. We bake fresh breads, pastries, and traditional African treats every morning.', 'bakery@ubuntucoffee.co.za', '+27821111112', '+27821111112', NULL, ST_SetSRID(ST_MakePoint(28.0480, -26.2050), 4326), '125 Rosebank Avenue', 'Johannesburg', 'Gauteng', '2196', 'ZA', 2023, '1-5', 'active', 'pending', NOW() - INTERVAL '2 days', '{}'),

('650e8400-e29b-41d4-a716-446655440007', '550e8400-e29b-41d4-a716-446655440011', 'Amandla Kids Collection', 'African-inspired children''s wear', 'Colorful, comfortable clothing for children aged 0-12 years, featuring African prints and modern designs.', 'kids@amandlafashion.co.za', '+27822222223', '+27822222223', NULL, ST_SetSRID(ST_MakePoint(18.4250, -33.9255), 4326), '47 Long Street', 'Cape Town', 'Western Cape', '8001', 'ZA', 2024, '1-5', 'active', 'pending', NOW() - INTERVAL '5 days', '{}'),

('650e8400-e29b-41d4-a716-446655440008', '550e8400-e29b-41d4-a716-446655440012', 'CodeAfrica Academy', 'Teaching coding to African youth', 'Free coding bootcamps for underprivileged youth. We teach web development, mobile apps, and data science.', 'info@codeafrica.org', '+27823333334', '+27823333334', 'https://codeafrica.org', ST_SetSRID(ST_MakePoint(31.0225, -29.8595), 4326), '90 Anton Lembede Street', 'Durban', 'KwaZulu-Natal', '4001', 'ZA', 2024, '1-5', 'active', 'pending', NOW() - INTERVAL '3 days', '{"non_profit": true}');

-- Draft Business (1)
INSERT INTO businesses (id, owner_id, name, tagline, description, email, phone_number, location, address_line1, city, province_state, postal_code, country, status, verification_status, metadata) VALUES
('650e8400-e29b-41d4-a716-446655440009', '550e8400-e29b-41d4-a716-446655440013', 'Zanele''s Catering', 'Premium catering for events', 'Professional catering services for weddings, corporate events, and private functions.', 'zanele.catering@example.com', '+27824444445', ST_SetSRID(ST_MakePoint(28.0300, -26.2030), 4326), '45 Main Road, Alexandra', 'Johannesburg', 'Gauteng', '2090', 'ZA', 'draft', 'pending', '{}');

-- Suspended Business (1)
INSERT INTO businesses (id, owner_id, name, tagline, description, email, phone_number, location, address_line1, city, province_state, postal_code, country, year_established, status, verification_status, metadata) VALUES
('650e8400-e29b-41d4-a716-446655440010', '550e8400-e29b-41d4-a716-446655440014', 'QuickCash Loans', 'Fast loans approved', 'Get cash loans within 24 hours.', 'info@quickcash.co.za', '+27825555556', ST_SetSRID(ST_MakePoint(28.0430, -26.1080), 4326), '100 Rivonia Road', 'Johannesburg', 'Gauteng', '2196', 'ZA', 2022, 'suspended', 'rejected', '{"suspension_reason": "Predatory lending practices"}');

-- ============================================================================
-- BUSINESS MEDIA
-- ============================================================================

-- Logos for verified businesses
INSERT INTO business_media (id, business_id, media_type, storage_path, file_name, mime_type, file_size_bytes, display_order, uploaded_at) VALUES
('750e8400-e29b-41d4-a716-446655440001', '650e8400-e29b-41d4-a716-446655440001', 'logo', 'businesses/ubuntu-coffee/logo.jpg', 'logo.jpg', 'image/jpeg', 245000, 1, NOW() - INTERVAL '30 days'),
('750e8400-e29b-41d4-a716-446655440002', '650e8400-e29b-41d4-a716-446655440002', 'logo', 'businesses/amandla-fashion/logo.jpg', 'logo.jpg', 'image/jpeg', 180000, 1, NOW() - INTERVAL '45 days'),
('750e8400-e29b-41d4-a716-446655440003', '650e8400-e29b-41d4-a716-446655440003', 'logo', 'businesses/techhub/logo.png', 'logo.png', 'image/png', 120000, 1, NOW() - INTERVAL '20 days'),
('750e8400-e29b-41d4-a716-446655440004', '650e8400-e29b-41d4-a716-446655440004', 'logo', 'businesses/mama-zaneles/logo.jpg', 'logo.jpg', 'image/jpeg', 200000, 1, NOW() - INTERVAL '60 days'),
('750e8400-e29b-41d4-a716-446655440005', '650e8400-e29b-41d4-a716-446655440005', 'logo', 'businesses/tumis-hair/logo.jpg', 'logo.jpg', 'image/jpeg', 190000, 1, NOW() - INTERVAL '40 days');

-- Photos for Ubuntu Coffee (3 photos - max allowed)
INSERT INTO business_media (id, business_id, media_type, storage_path, file_name, mime_type, file_size_bytes, display_order, alt_text, uploaded_at) VALUES
('750e8400-e29b-41d4-a716-446655440010', '650e8400-e29b-41d4-a716-446655440001', 'photo', 'businesses/ubuntu-coffee/interior.jpg', 'interior.jpg', 'image/jpeg', 450000, 1, 'Warm café interior with community seating', NOW() - INTERVAL '30 days'),
('750e8400-e29b-41d4-a716-446655440011', '650e8400-e29b-41d4-a716-446655440001', 'photo', 'businesses/ubuntu-coffee/coffee-art.jpg', 'coffee-art.jpg', 'image/jpeg', 380000, 2, 'Barista creating latte art', NOW() - INTERVAL '30 days'),
('750e8400-e29b-41d4-a716-446655440012', '650e8400-e29b-41d4-a716-446655440001', 'photo', 'businesses/ubuntu-coffee/beans.jpg', 'beans.jpg', 'image/jpeg', 420000, 3, 'Fresh roasted coffee beans', NOW() - INTERVAL '30 days');

-- Photos for Amandla Fashion (2 photos)
INSERT INTO business_media (id, business_id, media_type, storage_path, file_name, mime_type, file_size_bytes, display_order, alt_text, uploaded_at) VALUES
('750e8400-e29b-41d4-a716-446655440020', '650e8400-e29b-41d4-a716-446655440002', 'photo', 'businesses/amandla-fashion/showroom.jpg', 'showroom.jpg', 'image/jpeg', 500000, 1, 'Fashion showroom with African prints', NOW() - INTERVAL '45 days'),
('750e8400-e29b-41d4-a716-446655440021', '650e8400-e29b-41d4-a716-446655440002', 'photo', 'businesses/amandla-fashion/collection.jpg', 'collection.jpg', 'image/jpeg', 480000, 2, 'Latest collection pieces', NOW() - INTERVAL '45 days');

-- ============================================================================
-- BUSINESS HOURS
-- ============================================================================

-- Ubuntu Coffee Hours (Mon-Sat, Closed Sunday)
INSERT INTO business_hours (id, business_id, day_of_week, opens_at, closes_at, is_closed) VALUES
('850e8400-e29b-41d4-a716-446655440001', '650e8400-e29b-41d4-a716-446655440001', 'monday', '07:00', '18:00', false),
('850e8400-e29b-41d4-a716-446655440002', '650e8400-e29b-41d4-a716-446655440001', 'tuesday', '07:00', '18:00', false),
('850e8400-e29b-41d4-a716-446655440003', '650e8400-e29b-41d4-a716-446655440001', 'wednesday', '07:00', '18:00', false),
('850e8400-e29b-41d4-a716-446655440004', '650e8400-e29b-41d4-a716-446655440001', 'thursday', '07:00', '18:00', false),
('850e8400-e29b-41d4-a716-446655440005', '650e8400-e29b-41d4-a716-446655440001', 'friday', '07:00', '18:00', false),
('850e8400-e29b-41d4-a716-446655440006', '650e8400-e29b-41d4-a716-446655440001', 'saturday', '08:00', '16:00', false),
('850e8400-e29b-41d4-a716-446655440007', '650e8400-e29b-41d4-a716-446655440001', 'sunday', NULL, NULL, true);

-- Amandla Fashion Hours (Mon-Fri, Half-day Saturday)
INSERT INTO business_hours (id, business_id, day_of_week, opens_at, closes_at, is_closed) VALUES
('850e8400-e29b-41d4-a716-446655440010', '650e8400-e29b-41d4-a716-446655440002', 'monday', '09:00', '17:00', false),
('850e8400-e29b-41d4-a716-446655440011', '650e8400-e29b-41d4-a716-446655440002', 'tuesday', '09:00', '17:00', false),
('850e8400-e29b-41d4-a716-446655440012', '650e8400-e29b-41d4-a716-446655440002', 'wednesday', '09:00', '17:00', false),
('850e8400-e29b-41d4-a716-446655440013', '650e8400-e29b-41d4-a716-446655440002', 'thursday', '09:00', '17:00', false),
('850e8400-e29b-41d4-a716-446655440014', '650e8400-e29b-41d4-a716-446655440002', 'friday', '09:00', '17:00', false),
('850e8400-e29b-41d4-a716-446655440015', '650e8400-e29b-41d4-a716-446655440002', 'saturday', '09:00', '13:00', false),
('850e8400-e29b-41d4-a716-446655440016', '650e8400-e29b-41d4-a716-446655440002', 'sunday', NULL, NULL, true);

-- Mama Zanele's Kitchen Hours (Every day)
INSERT INTO business_hours (id, business_id, day_of_week, opens_at, closes_at, is_closed) VALUES
('850e8400-e29b-41d4-a716-446655440020', '650e8400-e29b-41d4-a716-446655440004', 'monday', '11:00', '22:00', false),
('850e8400-e29b-41d4-a716-446655440021', '650e8400-e29b-41d4-a716-446655440004', 'tuesday', '11:00', '22:00', false),
('850e8400-e29b-41d4-a716-446655440022', '650e8400-e29b-41d4-a716-446655440004', 'wednesday', '11:00', '22:00', false),
('850e8400-e29b-41d4-a716-446655440023', '650e8400-e29b-41d4-a716-446655440004', 'thursday', '11:00', '22:00', false),
('850e8400-e29b-41d4-a716-446655440024', '650e8400-e29b-41d4-a716-446655440004', 'friday', '11:00', '23:00', false),
('850e8400-e29b-41d4-a716-446655440025', '650e8400-e29b-41d4-a716-446655440004', 'saturday', '11:00', '23:00', false),
('850e8400-e29b-41d4-a716-446655440026', '650e8400-e29b-41d4-a716-446655440004', 'sunday', '12:00', '22:00', false);

-- ============================================================================
-- BUSINESS CATEGORIES
-- ============================================================================

INSERT INTO business_categories (id, business_id, category_name) VALUES
-- Ubuntu Coffee
('950e8400-e29b-41d4-a716-446655440001', '650e8400-e29b-41d4-a716-446655440001', 'Food & Beverage'),
('950e8400-e29b-41d4-a716-446655440002', '650e8400-e29b-41d4-a716-446655440001', 'Coffee Shop'),
('950e8400-e29b-41d4-a716-446655440003', '650e8400-e29b-41d4-a716-446655440001', 'Cafe'),

-- Amandla Fashion
('950e8400-e29b-41d4-a716-446655440010', '650e8400-e29b-41d4-a716-446655440002', 'Fashion & Apparel'),
('950e8400-e29b-41d4-a716-446655440011', '650e8400-e29b-41d4-a716-446655440002', 'Designer Clothing'),
('950e8400-e29b-41d4-a716-446655440012', '650e8400-e29b-41d4-a716-446655440002', 'African Fashion'),

-- TechHub
('950e8400-e29b-41d4-a716-446655440020', '650e8400-e29b-41d4-a716-446655440003', 'Technology'),
('950e8400-e29b-41d4-a716-446655440021', '650e8400-e29b-41d4-a716-446655440003', 'Co-working Space'),
('950e8400-e29b-41d4-a716-446655440022', '650e8400-e29b-41d4-a716-446655440003', 'Business Services'),

-- Mama Zanele's Kitchen
('950e8400-e29b-41d4-a716-446655440030', '650e8400-e29b-41d4-a716-446655440004', 'Food & Beverage'),
('950e8400-e29b-41d4-a716-446655440031', '650e8400-e29b-41d4-a716-446655440004', 'Restaurant'),
('950e8400-e29b-41d4-a716-446655440032', '650e8400-e29b-41d4-a716-446655440004', 'African Cuisine'),

-- Tumi's Hair Studio
('950e8400-e29b-41d4-a716-446655440040', '650e8400-e29b-41d4-a716-446655440005', 'Beauty & Wellness'),
('950e8400-e29b-41d4-a716-446655440041', '650e8400-e29b-41d4-a716-446655440005', 'Hair Salon'),
('950e8400-e29b-41d4-a716-446655440042', '650e8400-e29b-41d4-a716-446655440005', 'Natural Hair Care');

-- ============================================================================
-- FAVORITES
-- ============================================================================

-- Lindiwe's favorites (5 businesses)
INSERT INTO favorites (id, user_id, business_id) VALUES
('a50e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440001', '650e8400-e29b-41d4-a716-446655440001'),
('a50e8400-e29b-41d4-a716-446655440002', '550e8400-e29b-41d4-a716-446655440001', '650e8400-e29b-41d4-a716-446655440002'),
('a50e8400-e29b-41d4-a716-446655440003', '550e8400-e29b-41d4-a716-446655440001', '650e8400-e29b-41d4-a716-446655440003'),
('a50e8400-e29b-41d4-a716-446655440004', '550e8400-e29b-41d4-a716-446655440001', '650e8400-e29b-41d4-a716-446655440004'),
('a50e8400-e29b-41d4-a716-446655440005', '550e8400-e29b-41d4-a716-446655440001', '650e8400-e29b-41d4-a716-446655440005');

-- Thabo's favorites (4 businesses)
INSERT INTO favorites (id, user_id, business_id) VALUES
('a50e8400-e29b-41d4-a716-446655440010', '550e8400-e29b-41d4-a716-446655440002', '650e8400-e29b-41d4-a716-446655440002'),
('a50e8400-e29b-41d4-a716-446655440011', '550e8400-e29b-41d4-a716-446655440002', '650e8400-e29b-41d4-a716-446655440003'),
('a50e8400-e29b-41d4-a716-446655440012', '550e8400-e29b-41d4-a716-446655440002', '650e8400-e29b-41d4-a716-446655440004'),
('a50e8400-e29b-41d4-a716-446655440013', '550e8400-e29b-41d4-a716-446655440002', '650e8400-e29b-41d4-a716-446655440005');

-- Nomsa's favorites (3 businesses)
INSERT INTO favorites (id, user_id, business_id) VALUES
('a50e8400-e29b-41d4-a716-446655440020', '550e8400-e29b-41d4-a716-446655440003', '650e8400-e29b-41d4-a716-446655440003'),
('a50e8400-e29b-41d4-a716-446655440021', '550e8400-e29b-41d4-a716-446655440003', '650e8400-e29b-41d4-a716-446655440004'),
('a50e8400-e29b-41d4-a716-446655440022', '550e8400-e29b-41d4-a716-446655440003', '650e8400-e29b-41d4-a716-446655440005');

-- ============================================================================
-- MESSAGE THREADS
-- ============================================================================

-- Thread 1: Lindiwe → Ubuntu Coffee
INSERT INTO threads (id, consumer_id, supplier_id, business_id, subject, last_message_at) VALUES
('b50e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440010', '650e8400-e29b-41d4-a716-446655440001', 'Inquiry about catering services', NOW() - INTERVAL '1 day');

-- Thread 2: Thabo → Amandla Fashion
INSERT INTO threads (id, consumer_id, supplier_id, business_id, subject, last_message_at) VALUES
('b50e8400-e29b-41d4-a716-446655440002', '550e8400-e29b-41d4-a716-446655440002', '550e8400-e29b-41d4-a716-446655440011', '650e8400-e29b-41d4-a716-446655440002', 'Custom suit inquiry', NOW() - INTERVAL '3 days');

-- Thread 3: Nomsa → TechHub
INSERT INTO threads (id, consumer_id, supplier_id, business_id, subject, last_message_at) VALUES
('b50e8400-e29b-41d4-a716-446655440003', '550e8400-e29b-41d4-a716-446655440003', '550e8400-e29b-41d4-a716-446655440012', '650e8400-e29b-41d4-a716-446655440003', 'Membership options', NOW() - INTERVAL '2 hours');

-- Thread 4: Lindiwe → Mama Zanele's
INSERT INTO threads (id, consumer_id, supplier_id, business_id, subject, last_message_at) VALUES
('b50e8400-e29b-41d4-a716-446655440004', '550e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440013', '650e8400-e29b-41d4-a716-446655440004', 'Table reservation', NOW() - INTERVAL '5 hours');

-- Thread 5: Thabo → Tumi's Hair
INSERT INTO threads (id, consumer_id, supplier_id, business_id, subject, last_message_at) VALUES
('b50e8400-e29b-41d4-a716-446655440005', '550e8400-e29b-41d4-a716-446655440002', '550e8400-e29b-41d4-a716-446655440014', '650e8400-e29b-41d4-a716-446655440005', 'Appointment availability', NOW() - INTERVAL '6 days');

-- ============================================================================
-- MESSAGES
-- ============================================================================

-- Thread 1 Messages (Lindiwe → Ubuntu Coffee)
INSERT INTO messages (id, thread_id, sender_id, message_text, created_at) VALUES
('c50e8400-e29b-41d4-a716-446655440001', 'b50e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440001', 'Hi! I''m planning a corporate event for 30 people next month. Do you offer catering services?', NOW() - INTERVAL '1 day 2 hours'),
('c50e8400-e29b-41d4-a716-446655440002', 'b50e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440010', 'Hi Lindiwe! Yes, we absolutely do corporate catering. We can provide coffee service, pastries, and light lunch options. What date are you looking at?', NOW() - INTERVAL '1 day 1 hour'),
('c50e8400-e29b-41d4-a716-446655440003', 'b50e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440001', 'It''s for December 15th, from 9am to 3pm. We''ll need breakfast and lunch options.', NOW() - INTERVAL '1 day'),
('c50e8400-e29b-41d4-a716-446655440004', 'b50e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440010', 'Perfect! That date is available. I''ll send you our catering menu and pricing. Can I get your email?', NOW() - INTERVAL '1 day');

-- Thread 2 Messages (Thabo → Amandla Fashion)
INSERT INTO messages (id, thread_id, sender_id, message_text, created_at) VALUES
('c50e8400-e29b-41d4-a716-446655440010', 'b50e8400-e29b-41d4-a716-446655440002', '550e8400-e29b-41d4-a716-446655440002', 'Hello, I need a custom suit for my wedding in February. Do you do bespoke menswear?', NOW() - INTERVAL '3 days 5 hours'),
('c50e8400-e29b-41d4-a716-446655440011', 'b50e8400-e29b-41d4-a716-446655440002', '550e8400-e29b-41d4-a716-446655440011', 'Congratulations on your wedding! Yes, we create custom suits. We''d love to design something special with African-inspired fabrics. Can you come in for a consultation?', NOW() - INTERVAL '3 days');

-- Thread 3 Messages (Nomsa → TechHub)
INSERT INTO messages (id, thread_id, sender_id, message_text, created_at) VALUES
('c50e8400-e29b-41d4-a716-446655440020', 'b50e8400-e29b-41d4-a716-446655440003', '550e8400-e29b-41d4-a716-446655440003', 'Hi! I''m a freelance developer and interested in your co-working space. What membership options do you have?', NOW() - INTERVAL '2 hours 30 minutes'),
('c50e8400-e29b-41d4-a716-446655440021', 'b50e8400-e29b-41d4-a716-446655440003', '550e8400-e29b-41d4-a716-446655440012', 'Welcome! We have hot desks (R2000/month), dedicated desks (R3500/month), and private offices (R8000/month). All include high-speed internet, meeting rooms, and mentorship access. Would you like to book a tour?', NOW() - INTERVAL '2 hours');

-- Thread 4 Messages (Lindiwe → Mama Zanele's)
INSERT INTO messages (id, thread_id, sender_id, message_text, created_at) VALUES
('c50e8400-e29b-41d4-a716-446655440030', 'b50e8400-e29b-41d4-a716-446655440004', '550e8400-e29b-41d4-a716-446655440001', 'Good afternoon! Can I book a table for 6 people tonight at 7pm?', NOW() - INTERVAL '5 hours 15 minutes'),
('c50e8400-e29b-41d4-a716-446655440031', 'b50e8400-e29b-41d4-a716-446655440004', '550e8400-e29b-41d4-a716-446655440013', 'Hi Lindiwe! Yes, we have availability for 6 at 7pm. Can I get your phone number for confirmation?', NOW() - INTERVAL '5 hours');

-- Thread 5 Messages (Thabo → Tumi's Hair)
INSERT INTO messages (id, thread_id, sender_id, message_text, created_at) VALUES
('c50e8400-e29b-41d4-a716-446655440040', 'b50e8400-e29b-41d4-a716-446655440005', '550e8400-e29b-41d4-a716-446655440002', 'Hi Tumi, do you have availability for a cut and style this weekend?', NOW() - INTERVAL '6 days 10 hours'),
('c50e8400-e29b-41d4-a716-446655440041', 'b50e8400-e29b-41d4-a716-446655440005', '550e8400-e29b-41d4-a716-446655440014', 'Hi Thabo! I have a slot on Saturday at 2pm. Does that work?', NOW() - INTERVAL '6 days 8 hours'),
('c50e8400-e29b-41d4-a716-446655440042', 'b50e8400-e29b-41d4-a716-446655440005', '550e8400-e29b-41d4-a716-446655440002', 'Perfect! I''ll take it. See you Saturday!', NOW() - INTERVAL '6 days 8 hours');

-- ============================================================================
-- VERIFICATION REQUESTS
-- ============================================================================

-- Approved verification (Ubuntu Coffee)
INSERT INTO verification_requests (id, business_id, requester_id, status, reviewed_by, reviewed_at, review_notes) VALUES
('d50e8400-e29b-41d4-a716-446655440001', '650e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440010', 'approved', '550e8400-e29b-41d4-a716-446655440100', NOW() - INTERVAL '30 days', 'Business registration documents verified. Ownership confirmed.');

-- Pending verification (Ubuntu Bakery)
INSERT INTO verification_requests (id, business_id, requester_id, status) VALUES
('d50e8400-e29b-41d4-a716-446655440002', '650e8400-e29b-41d4-a716-446655440006', '550e8400-e29b-41d4-a716-446655440010', 'pending');

-- Rejected verification (QuickCash Loans)
INSERT INTO verification_requests (id, business_id, requester_id, status, reviewed_by, reviewed_at, review_notes) VALUES
('d50e8400-e29b-41d4-a716-446655440003', '650e8400-e29b-41d4-a716-446655440010', '550e8400-e29b-41d4-a716-446655440014', 'rejected', '550e8400-e29b-41d4-a716-446655440100', NOW() - INTERVAL '15 days', 'Business does not meet platform guidelines. Predatory lending practices.');

-- ============================================================================
-- VERIFICATION DOCUMENTS
-- ============================================================================

-- Documents for approved verification (Ubuntu Coffee)
INSERT INTO verification_documents (id, verification_request_id, document_type, storage_path, file_name, uploaded_at) VALUES
('e50e8400-e29b-41d4-a716-446655440001', 'd50e8400-e29b-41d4-a716-446655440001', 'business_registration', 'verification/ubuntu-coffee/cipc-registration.pdf', 'cipc-registration.pdf', NOW() - INTERVAL '31 days'),
('e50e8400-e29b-41d4-a716-446655440002', 'd50e8400-e29b-41d4-a716-446655440001', 'identity_document', 'verification/ubuntu-coffee/owner-id.pdf', 'owner-id.pdf', NOW() - INTERVAL '31 days');

-- Documents for pending verification (Ubuntu Bakery)
INSERT INTO verification_documents (id, verification_request_id, document_type, storage_path, file_name, uploaded_at) VALUES
('e50e8400-e29b-41d4-a716-446655440010', 'd50e8400-e29b-41d4-a716-446655440002', 'business_registration', 'verification/ubuntu-bakery/cipc-registration.pdf', 'cipc-registration.pdf', NOW() - INTERVAL '2 days');

-- ============================================================================
-- COMPLETION - VERIFY DATA COUNTS
-- ============================================================================

SELECT 'Users' as table_name, COUNT(*) as count FROM users
UNION ALL
SELECT 'Businesses', COUNT(*) FROM businesses
UNION ALL
SELECT 'Business Media', COUNT(*) FROM business_media
UNION ALL
SELECT 'Business Hours', COUNT(*) FROM business_hours
UNION ALL
SELECT 'Business Categories', COUNT(*) FROM business_categories
UNION ALL
SELECT 'Favorites', COUNT(*) FROM favorites
UNION ALL
SELECT 'Threads', COUNT(*) FROM threads
UNION ALL
SELECT 'Messages', COUNT(*) FROM messages
UNION ALL
SELECT 'Verification Requests', COUNT(*) FROM verification_requests
UNION ALL
SELECT 'Verification Documents', COUNT(*) FROM verification_documents;

-- Test geospatial query (businesses near Johannesburg)
SELECT 
    name,
    city,
    ROUND(ST_Distance(location::geography, ST_SetSRID(ST_MakePoint(28.0473, -26.2041), 4326)::geography)::numeric, 2) as distance_meters
FROM businesses
WHERE status = 'active' AND verification_status = 'approved'
ORDER BY location <-> ST_SetSRID(ST_MakePoint(28.0473, -26.2041), 4326)::geography
LIMIT 5;
