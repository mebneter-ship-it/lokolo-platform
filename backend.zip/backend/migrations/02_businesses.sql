-- ============================================================
-- Lokolo Platform - Businesses Table
-- Version: 1.0
-- Description: Business listings with geospatial support (PostGIS)
-- ============================================================

CREATE TABLE IF NOT EXISTS businesses (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    
    -- Basic Info
    name VARCHAR(255) NOT NULL,
    tagline VARCHAR(255),
    description TEXT,
    
    -- Contact
    email VARCHAR(255),
    phone_number VARCHAR(20),
    whatsapp_number VARCHAR(20),
    website_url TEXT,
    
    -- Location (PostGIS)
    location GEOGRAPHY(Point, 4326) NOT NULL,
    address_line1 VARCHAR(255),
    address_line2 VARCHAR(255),
    city VARCHAR(100) NOT NULL,
    province_state VARCHAR(100),
    postal_code VARCHAR(20),
    country VARCHAR(2) NOT NULL DEFAULT 'ZA', -- ISO 3166-1 alpha-2
    
    -- Business Details
    year_established INTEGER,
    employee_count_range VARCHAR(20), -- e.g., "1-10", "11-50"
    
    -- Status & Verification
    status business_status NOT NULL DEFAULT 'draft',
    verification_status verification_status NOT NULL DEFAULT 'pending',
    verified_at TIMESTAMP,
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    published_at TIMESTAMP,
    
    -- Metadata
    metadata JSONB DEFAULT '{}'::jsonb,
    
    -- Constraints
    CONSTRAINT businesses_name_check CHECK (char_length(name) >= 2),
    CONSTRAINT businesses_year_check CHECK (year_established IS NULL OR (year_established >= 1800 AND year_established <= EXTRACT(YEAR FROM CURRENT_DATE)))
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_businesses_owner_id ON businesses(owner_id);
CREATE INDEX IF NOT EXISTS idx_businesses_status ON businesses(status);
CREATE INDEX IF NOT EXISTS idx_businesses_verification_status ON businesses(verification_status);
CREATE INDEX IF NOT EXISTS idx_businesses_city ON businesses(city);
CREATE INDEX IF NOT EXISTS idx_businesses_country ON businesses(country);
CREATE INDEX IF NOT EXISTS idx_businesses_created_at ON businesses(created_at);

-- CRITICAL: Geospatial index using GIST for location-based queries
CREATE INDEX IF NOT EXISTS idx_businesses_location ON businesses USING GIST(location);

-- Full-text search index for name and description
CREATE INDEX IF NOT EXISTS idx_businesses_name_trgm ON businesses USING gin(name gin_trgm_ops);
CREATE EXTENSION IF NOT EXISTS pg_trgm; -- Trigram extension for fuzzy search

-- Updated_at trigger
CREATE TRIGGER businesses_updated_at
    BEFORE UPDATE ON businesses
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Update schema version
INSERT INTO schema_version (version, description) 
VALUES ('1.2', 'Added businesses table with PostGIS geospatial support')
ON CONFLICT (version) DO NOTHING;