-- ============================================================
-- Lokolo Platform - Business Categories Table
-- Version: 1.0
-- Description: Categories/industries for businesses (many-to-many)
-- ============================================================

CREATE TABLE IF NOT EXISTS business_categories (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    
    -- Category
    category_name VARCHAR(100) NOT NULL,
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Constraints
    CONSTRAINT business_categories_unique UNIQUE(business_id, category_name)
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_business_categories_business_id ON business_categories(business_id);
CREATE INDEX IF NOT EXISTS idx_business_categories_name ON business_categories(category_name);

-- Update schema version
INSERT INTO schema_version (version, description) 
VALUES ('1.5', 'Added business_categories table for industry classification')
ON CONFLICT (version) DO NOTHING;
