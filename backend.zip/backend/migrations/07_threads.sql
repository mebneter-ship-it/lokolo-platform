-- ============================================================
-- Lokolo Platform - Threads Table
-- Version: 1.0
-- Description: Messaging threads between consumers and suppliers
-- ============================================================

DROP TABLE IF EXISTS threads CASCADE;

CREATE TABLE threads (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    consumer_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    supplier_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    
    -- Thread Metadata
    subject VARCHAR(255),
    last_message_at TIMESTAMP,
    
    -- Status
    is_archived_by_consumer BOOLEAN DEFAULT FALSE,
    is_archived_by_supplier BOOLEAN DEFAULT FALSE,
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Constraints: One thread per consumer-business pair
    CONSTRAINT threads_unique UNIQUE(consumer_id, business_id),
    CONSTRAINT threads_different_users CHECK (consumer_id != supplier_id)
);

-- Indexes for performance
DROP INDEX IF EXISTS idx_threads_consumer_id;
DROP INDEX IF EXISTS idx_threads_supplier_id;
DROP INDEX IF EXISTS idx_threads_business_id;
DROP INDEX IF EXISTS idx_threads_last_message_at;

CREATE INDEX idx_threads_consumer_id ON threads(consumer_id);
CREATE INDEX idx_threads_supplier_id ON threads(supplier_id);
CREATE INDEX idx_threads_business_id ON threads(business_id);
CREATE INDEX idx_threads_last_message_at ON threads(last_message_at);

-- Updated_at trigger
CREATE TRIGGER threads_updated_at
    BEFORE UPDATE ON threads
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Update schema version
INSERT INTO schema_version (version, description) 
VALUES ('1.7', 'Added threads table for consumer-supplier messaging')
ON CONFLICT (version) DO NOTHING;
