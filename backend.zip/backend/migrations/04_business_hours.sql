-- ============================================================
-- Lokolo Platform - Business Hours Table
-- Version: 1.0
-- Description: Operating hours for businesses by day of week
-- ============================================================

CREATE TABLE IF NOT EXISTS business_hours (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    
    -- Day and Hours
    day_of_week day_of_week NOT NULL,
    opens_at TIME,
    closes_at TIME,
    is_closed BOOLEAN DEFAULT FALSE,
    
    -- Special Notes
    notes VARCHAR(255),
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Constraints
    CONSTRAINT business_hours_unique_day UNIQUE(business_id, day_of_week),
    CONSTRAINT business_hours_time_check CHECK (
        is_closed = TRUE OR (opens_at IS NOT NULL AND closes_at IS NOT NULL)
    ),
    CONSTRAINT business_hours_valid_times CHECK (
        is_closed = TRUE OR closes_at > opens_at
    )
);

CREATE INDEX IF NOT EXISTS idx_business_hours_business_id ON business_hours(business_id);
CREATE INDEX IF NOT EXISTS idx_business_hours_day ON business_hours(day_of_week);

CREATE TRIGGER business_hours_updated_at
    BEFORE UPDATE ON business_hours
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

INSERT INTO schema_version (version, description) 
VALUES ('1.4', 'Added business_hours table for operating hours')
ON CONFLICT (version) DO NOTHING;
