-- ============================================================
-- Lokolo Platform - Verification Requests Table
-- Version: 1.0
-- Description: Business verification requests from suppliers
-- ============================================================

DROP TABLE IF EXISTS verification_requests CASCADE;

CREATE TABLE verification_requests (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    requester_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    
    -- Request Details
    request_notes TEXT,
    
    -- Status & Review
    status verification_status NOT NULL DEFAULT 'pending',
    reviewed_by UUID REFERENCES users(id) ON DELETE SET NULL,
    reviewed_at TIMESTAMP,
    review_notes TEXT,
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for performance
DROP INDEX IF EXISTS idx_verification_requests_business_id;
DROP INDEX IF EXISTS idx_verification_requests_requester_id;
DROP INDEX IF EXISTS idx_verification_requests_status;
DROP INDEX IF EXISTS idx_verification_requests_reviewed_by;

CREATE INDEX idx_verification_requests_business_id ON verification_requests(business_id);
CREATE INDEX idx_verification_requests_requester_id ON verification_requests(requester_id);
CREATE INDEX idx_verification_requests_status ON verification_requests(status);
CREATE INDEX idx_verification_requests_reviewed_by ON verification_requests(reviewed_by);

-- Updated_at trigger
CREATE TRIGGER verification_requests_updated_at
    BEFORE UPDATE ON verification_requests
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Update schema version
INSERT INTO schema_version (version, description) 
VALUES ('1.9', 'Added verification_requests table for business verification')
ON CONFLICT (version) DO NOTHING;
