-- ============================================================
-- Lokolo Platform - Verification Documents Table
-- Version: 1.0
-- Description: Documents uploaded for business verification
-- ============================================================

DROP TABLE IF EXISTS verification_documents CASCADE;

CREATE TABLE verification_documents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    verification_request_id UUID NOT NULL REFERENCES verification_requests(id) ON DELETE CASCADE,
    
    -- Document Details
    document_type VARCHAR(100) NOT NULL, -- e.g., "business_license", "tax_certificate"
    storage_path TEXT NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_size_bytes INTEGER,
    mime_type VARCHAR(100),
    
    -- Timestamps
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Metadata
    metadata JSONB DEFAULT '{}'::jsonb
);

-- Indexes for performance
DROP INDEX IF EXISTS idx_verification_documents_request_id;
DROP INDEX IF EXISTS idx_verification_documents_type;

CREATE INDEX idx_verification_documents_request_id ON verification_documents(verification_request_id);
CREATE INDEX idx_verification_documents_type ON verification_documents(document_type);

-- Update schema version
INSERT INTO schema_version (version, description) 
VALUES ('1.10', 'Added verification_documents table for verification uploads')
ON CONFLICT (version) DO NOTHING;
